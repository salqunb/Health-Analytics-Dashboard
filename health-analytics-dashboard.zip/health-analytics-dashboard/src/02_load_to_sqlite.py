"""Step 2: load the clean CSV into a SQLite database (data/health.db)."""
import sqlite3
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
df = pd.read_csv(ROOT / "data" / "processed" / "health_clean.csv")

with sqlite3.connect(ROOT / "data" / "health.db") as conn:
    df.to_sql("health_data", conn, if_exists="replace", index=False)
    n = conn.execute("SELECT COUNT(*) FROM health_data").fetchone()[0]
print(f"Table health_data created with {n} rows in data/health.db")
