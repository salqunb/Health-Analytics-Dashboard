"""Step 3: run every query in sql/analysis_queries.sql and print the results."""
import sqlite3
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sql_text = (ROOT / "sql" / "analysis_queries.sql").read_text()

with sqlite3.connect(ROOT / "data" / "health.db") as conn:
    for block in sql_text.split(";"):
        block = block.strip()
        if not block:
            continue
        title = block.splitlines()[0].lstrip("- ").strip()
        print(f"\n=== {title} ===")
        print(pd.read_sql_query(block, conn).to_string(index=False))
